package edu.cecyt9.ipn.games;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DinoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dino);

        setTitle(R.string.Main_btn3);
    }
}
