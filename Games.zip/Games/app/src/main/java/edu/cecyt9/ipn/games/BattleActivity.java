package edu.cecyt9.ipn.games;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BattleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle);

        setTitle(R.string.Main_btn2);
    }
}
