package edu.cecyt9.ipn.games;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;

public class MemoActivity extends AppCompatActivity {

    Button[] btns;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo);

        setTitle(R.string.Main_btn1);
        GridLayout Grid = findViewById(R.id.M_Grid);
        Intent algo = getIntent();
        int algopor2 = algo.getIntExtra("Dificultad", 3);
        System.out.println(Grid.getWidth());
        for (int i = 0; i < algopor2 * algopor2; i++) {
            Button x = new Button(this);
            Grid.setColumnCount(algopor2);
            Grid.addView(x, 100, 100);
        }
    }
    
}
