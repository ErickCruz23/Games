package edu.cecyt9.ipn.games;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;

public class MemoActivity extends AppCompatActivity {

    Button[] btns;
    int ancho = 3, alto = 5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo);

        setTitle(R.string.Main_btn1);
        GridLayout Grid = findViewById(R.id.M_Grid);
        for (int i = 0; i < ancho * alto; i++) {
            Button x = new Button(this);
//            x.setWidth(114);
            Grid.setColumnCount(ancho);
            Grid.addView(x, 144, 144);
        }
    }
}
