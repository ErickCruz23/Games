package edu.cecyt9.ipn.games;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class NivelActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nivel);
        setTitle(R.string.Nivel_title);
    }

    @Override
    public void onClick(View v) {
        int Nivel = 0;
        switch (v.getId()) {
            case R.id.N_button1:
                Nivel = 3;
                break;
            case R.id.N_button2:
                Nivel = 4;
                break;
            case R.id.N_button3:
                Nivel = 5;
                break;
        }
        Intent Memorama = new Intent(this, MemoActivity.class);
        Memorama.putExtra("Dificultad", Nivel);
        startActivity(Memorama);
    }
}
