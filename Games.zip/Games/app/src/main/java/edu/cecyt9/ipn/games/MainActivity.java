package edu.cecyt9.ipn.games;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:
                Intent Gato = new Intent(this, GatoActivity.class);
                startActivity(Gato);
                break;
            case R.id.button2:
                Intent Memo = new Intent(this, MemoActivity.class);
                startActivity(Memo);
                break;
            case R.id.button3:
                Intent Battle = new Intent(this, BattleActivity.class);
                startActivity(Battle);
                break;
            case R.id.button4:
                Intent Dino = new Intent(this, DinoActivity.class);
                startActivity(Dino);
                break;
            case R.id.button5:
                Intent Maicra = new Intent(this, MaicraActivity.class);
                startActivity(Maicra);
                break;
        }
    }
}
