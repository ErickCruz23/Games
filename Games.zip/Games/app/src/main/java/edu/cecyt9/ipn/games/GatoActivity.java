package edu.cecyt9.ipn.games;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GatoActivity extends AppCompatActivity implements View.OnClickListener {

    Button[] btns;
    Button Reintentar;
    boolean Turno;
    String X = "X", O = "O", msj = "Es turno de: ";
    TextView lbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gato);

        setTitle(R.string.Main_btn0);
        lbl = findViewById(R.id.G_lbl);
        btns = new Button[]{
                findViewById(R.id.G_button1), findViewById(R.id.G_button2), findViewById(R.id.G_button3),
                findViewById(R.id.G_button4), findViewById(R.id.G_button5), findViewById(R.id.G_button6),
                findViewById(R.id.G_button7), findViewById(R.id.G_button8), findViewById(R.id.G_button9)};
        Reintentar = findViewById(R.id.G_buttonR);
        ReiniciarJuego();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.G_buttonR) {
            ReiniciarJuego();
        } else {
            Button btnTemp = (Button) view;
            String victoria;

            btnTemp.setEnabled(false);
//            btnTemp.setTextColor(Color.BLACK);
            if (Turno) {
                btnTemp.setText(X);
                lbl.setText(msj + O);
                victoria = "¡" + X + " ha ganado!";
            } else {
                btnTemp.setText(O);
                lbl.setText(msj + X);
                victoria = "¡" + O + " ha ganado!";
            }
            if (VerticalButtons() || HorizontalButtons() || DiagonalButtons()) {
                for (Button btn : btns) {
                    btn.setEnabled(false);
                }
                lbl.setText(victoria);
                Reintentar.setVisibility(View.VISIBLE);
            } else if (IsFull()) {
                lbl.setText("Empate");
                Reintentar.setVisibility(View.VISIBLE);
            } else {
                Turno = !Turno;
            }
        }
    }

    private boolean VerticalButtons() {
        for (int i = 0; i < 3; i++) {
            if (Compare3(btns[i], btns[i + 3], btns[i + 6])) {
                return true;
            }
        }
        return false;
    }

    private boolean HorizontalButtons() {
        for (int i = 0; i < 7; i += 3) {
            if (Compare3(btns[i], btns[i + 1], btns[i + 2])) {
                return true;
            }
        }
        return false;
    }

    private boolean DiagonalButtons() {
        int[][] indices = new int[][]{{0, 4, 8}, {2, 4, 6}};
        for (int i = 0; i < 2; i++) {
            if (Compare3(btns[indices[i][0]], btns[indices[i][1]], btns[indices[i][2]])) {
                return true;
            }
        }
        return false;
    }

    private boolean Compare3(Button BtnX, Button BtnY, Button BtnZ) {
        CharSequence txt1 = BtnX.getText();
        CharSequence txt2 = BtnY.getText();
        CharSequence txt3 = BtnZ.getText();
        if (txt1.equals(X) || txt1.equals(O)) {
            if (txt1.equals(txt2) && txt1.equals(txt3)) {
                BtnX.setTextColor(Color.RED);
                BtnY.setTextColor(Color.RED);
                BtnZ.setTextColor(Color.RED);
                return true;
            }
        }
        return false;
    }

    private boolean IsFull() {
        for (Button btnTemp : btns) {
            if (btnTemp.isEnabled()) {
                return false;
            }
        }
        return true;
    }

    private void ReiniciarJuego() {
        for (Button btn : btns) {
            btn.setText("");
            btn.setEnabled(true);
        }

        int r = (int) (Math.random() * 2) + 1;
        System.out.println(r);
        if (r == 1) {
            Turno = true;
            lbl.setText(msj + X);
        } else if (r == 2) {
            Turno = false;
            lbl.setText(msj + O);
        }

        Reintentar.setVisibility(View.INVISIBLE);
    }
}
